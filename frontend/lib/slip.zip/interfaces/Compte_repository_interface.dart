import '../models/Compte.dart';

abstract class Compte_repository_interface {
  void ajouterCompte(Compte compte);
  Future<List<Compte>> ListerCompte();
  Future<Compte> trouverCompte(int id);
  Future<Compte> modifierCompte(Compte compte);
}
