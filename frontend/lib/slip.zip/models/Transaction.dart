import '../enums/TypeTransaction.dart';

class Transaction {
  late int _id;
  late TypeTransaction _type;
  static late int nbreTransaction = 0;
  late double _montant;
  late DateTime _date;

  @override
  String toString() {
    return 'Transaction{_id: $_id, _type: $_type, _montant: $_montant, _date: $_date}';
  }

  // constructeur avec et sans arguments
  Transaction.empty() {
    nbreTransaction++;
    _id = nbreTransaction;
    date = DateTime.now();
  }
  Transaction(this._id, this._type);

  Transaction.fromJson(Map<String, dynamic> json) {
    _id = json['id'] is String ? int.parse(json['id']) : json['id'];
    _type = getTypeTransaction(json['type']);
    _montant = json['montant'] is String
        ? double.parse(json['montant'])
        : json['montant'];
    _date =
        json['date'] is String ? DateTime.parse(json['date']) : json['date'];
  }

  Map<String, dynamic> toJson() => {
        "id": _id is String ? int.parse(_id.toString()) : _id,
        "type": _type.toString(),
        "montant":
            _montant is String ? double.parse(_montant.toString()) : _montant,
        "date": _date.toString()
      };

  int get id => _id;
  TypeTransaction get type => _type;
  double get montant => _montant;
  DateTime get date => _date;

  set id(int id) => _id = id;
  set type(TypeTransaction type) => _type = type;
  set montant(double montant) => _montant = montant;
  set date(DateTime date) => _date = date;
}
