import '../enums/TypeCompte.dart';
import 'Transaction.dart';

class Compte {
  late int _id;
  late String _numero;
  late DateTime _dateCreation;
  static late int _nbrCompte = 0;
  late double _solde;
  late Typecompte _typeCompte;
  List<Transaction?> _transactions = [];
  Duration? _dureeBlocage;
  DateTime? _dateDeblocage;
  double? _tauxInteret = 0.8;

  @override
  String toString() {
    return 'Compte{_id: $_id, _numero: $_numero, _dateCreation: $_dateCreation, _solde: $_solde, _transactions: $_transactions}';
  }

  Compte(this._id, this._numero, this._dateCreation, this._solde);

  Compte.empty() {
    _nbrCompte++;
    _id = _nbrCompte;
    _numero = "COMPTE-$_nbrCompte";
    _dateCreation = DateTime.now();
  }

  Compte.fromJson(Map<String, dynamic> json) {
    _id = json["id"] is String ? int.parse(json["id"]) : json["id"];
    _numero = json["numero"];
    _dateCreation = DateTime.parse(json["dateCreation"]);
    _solde =
        json["solde"] is String ? double.parse(json["solde"]) : json["solde"];
    if (json["transactions"] != null) {
      json["transactions"].forEach((v) {
        _transactions.add(Transaction.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() => {
        "id": _id is String ? int.parse(_id.toString()) : _id,
        "numero": _numero.toString(),
        "dateCreation": _dateCreation.toString(),
        "solde": _solde is String ? double.parse(_solde.toString()) : _solde,
        // "transactions": _transactions en json

        "transactions": _transactions.isNotEmpty
            ? _transactions.map((v) => v?.toJson()).toList()
            : [],
      };

  int get id => _id;
  String get numero => _numero;
  DateTime get dateCreation => _dateCreation;
  double get solde => _solde;
  List<Transaction?> get transactions => _transactions;
  Typecompte get typeCompte => _typeCompte;
  Duration? get dureeBlocage => _dureeBlocage;
  DateTime? get dateDeblocage => _dateDeblocage;
  double? get tauxInteret => _tauxInteret;

  set id(int id) => _id = id;
  set numero(String numero) => _numero = numero;
  set dateCreation(DateTime dateCreation) => _dateCreation = dateCreation;
  set solde(double solde) => _solde = solde;
  set dureeBlocage(Duration? dureeBlocage) => _dureeBlocage = dureeBlocage;
  set dateDeblocage(DateTime? dateDeblocage) => _dateDeblocage = dateDeblocage;
  set TypeCompte(Typecompte typeCompte) => _typeCompte = typeCompte;
  set transactionsList(List<Transaction> transactions) =>
      _transactions = transactions;
  void addTransaction(Transaction transaction) =>
      _transactions.add(transaction);
}
