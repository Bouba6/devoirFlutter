import 'dart:convert';

import '../interfaces/Compte_repository_interface.dart';
import '../models/Compte.dart';
import 'package:http/http.dart' as http;

class Compte_repository implements Compte_repository_interface {
  Uri url = Uri.parse('http://192.168.1.12:3000/Comptes');
  @override
  void ajouterCompte(Compte compte) async {
    try {
      final response = await http.post(
        url,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode(compte.toJson()),
      );

      if (response.statusCode == 201) {
        print("Compte ajouté");
      } else {
        print("Erreur lors de l'ajout du compte : ${response.statusCode}");
        print("Réponse serveur : ${response.body}");
      }
    } catch (e) {
      print("Exception réseau : $e");
    }
  }

  @override
  Future<List<Compte>> ListerCompte() async {
    final response = await http.get(url);

    if (response.statusCode == 200) {
      final body = response.body;

      if (body.isEmpty) {
        print("Réponse vide");
        return [];
      }

      final data = jsonDecode(body);

      if (data is List) {
        return data.map<Compte>((json) => Compte.fromJson(json)).toList();
      } else {
        print("Format inattendu : $data");
        return [];
      }
    } else {
      throw Exception('Failed to load comptes');
    }
  }

  @override
  Future<Compte> trouverCompte(int id) async {
    //get by id
    final response = await http.get(Uri.parse('$url/$id'));
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return Compte.fromJson(data);
    } else {
      throw Exception('Failed to load album');
    }
  }

  @override
  Future<Compte> modifierCompte(Compte compte) async {
    try {
      final response = await http.put(
        Uri.parse('$url/${compte.id}'), // Add the ID of the compte to the URL,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode(compte.toJson()),
      );

      if (response.statusCode == 200) {
        print("Compte modifié");
        return null!;
      } else {
        print(
          "Erreur lors de la modification du compte : ${response.statusCode}",
        );
        print("Réponse serveur : ${response.body}");
        throw Exception('Failed to modify compte');
      }
    } catch (e) {
      print("Exception réseau : $e");
      throw Exception(
        'Failed to modify compte',
      ); // Throw an exception if there's an error
    }
  }
}
